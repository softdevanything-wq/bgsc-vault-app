/* global BigInt */
import { ConnectButton, useAccountModal } from "@rainbow-me/rainbowkit";

import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useAccount, useBalance, usePublicClient } from "wagmi";
import toast from "react-hot-toast";
import { useLanguage } from "../../contexts/LanguageContext";
import { t } from "../../translations";
import HeaderLanguageToggle from "../../components/HeaderLanguageToggle";
import DepositStepModal from "../../components/DepositStepModal";
import WalletDisconnectedAlert from "../../components/WalletDisconnectedAlert";

import iconArrowRightSmall from "assets/icon-arrow-right-small.svg";
import textLogo from "assets/text_logo.png";
import messageIcon from "assets/icon-chat-bubble.svg";
import sendIcon from "assets/icon-send.svg";
import xIcon from "assets/icon-x.svg";

import { useVaultData, useTokenBalance } from "../../contexts/VaultDataContext";
import {
  useDepositActions,
  useWithdrawActions,
  useRedeemActions,
} from "../../hooks-actions";
import {
  useTransactionHistory,
  usePriceHistory,
  useLivePrice,
  useGasPrice,
  useRoundCountdown,
} from "hooks";
import {
  formatAmount,
  formatIntegerAmount,
  formatFullAmount,
  parseAmount,
  calculateBGSCFromPoints,
  calculatePointsFromBGSC,
  getTimeUntilNextRound,
  formatTimestamp,
  validateAmount,
  filterNumberInput,
  shortenAddress,
  getBSCScanLink,
  safeBigInt,
  getDynamicText,
  getCurrentRoundStatus,
  getInstantWithdrawDeadline,
  getNextRoundStartTime,
  estimateTransactionCost,
  SecurityUtils,
  MobileWalletUtils,
} from "utils";
import { getStyles } from "./styles";

import Icons from "../../components/Icons";

export default function MainPage() {
  // Language context
  const { language } = useLanguage();
  
  // Wallet connection state
  const { address, isConnected } = useAccount();
  const { openAccountModal } = useAccountModal();
  const publicClient = usePublicClient();

  // Vault data and hooks
  const {
    vaultInfo,
    vaultMetrics,
    userBalance,
    hasError,
    isLoading,
    refreshData,
    refreshAllData,
    refreshUserData,
    refreshCriticalData,
  } = useVaultData();
  const { balances, approvalStatus, approve, isApprovalSufficient, setApprovalStatus, isApproving: isApprovingFromHook, refreshBalances } = useTokenBalance();
  const { apy } = usePriceHistory();
  const { livePrice, priceChange } = useLivePrice();
  const { 
    transactions, 
    isLoadingHistory, 
    refreshHistory, 
    hasMoreHistory,
    currentPage,
    totalCount,
    itemsPerPage,
    changeItemsPerPage,
    goToPage,
    totalPages
  } = useTransactionHistory();
  const { gasPrices, calculateGasFee, isLoading: isGasLoading } = useGasPrice();
  const countdown = useRoundCountdown();
  const [isMobile, setIsMobile] = useState(false);
  const [isDappBrowser, setIsDappBrowser] = useState(false);

  // Action hooks - passing data as props to avoid duplicate instances
  const {
    handleDeposit,
    handleApproval,
    isLoading: isDepositing,
    needsApproval,
  } = useDepositActions(
    vaultInfo,
    balances,
    approve,
    isApprovalSufficient,
    approvalStatus,
    setApprovalStatus,
    refreshUserData
  );

  const {
    handleInstantWithdraw,
    handleInitiateWithdraw,
    handleCompleteWithdraw,
    isLoading: isWithdrawing,
  } = useWithdrawActions(
    vaultInfo,
    userBalance,
    refreshCriticalData,
    refreshUserData,
    refreshBalances
  );

  const {
    handleRedeem,
    handleMaxRedeem,
    isLoading: isRedeeming,
  } = useRedeemActions(
    vaultInfo,
    userBalance,
    refreshUserData
  );

  // UI state
  const [activeTab, setActiveTab] = useState(window.innerWidth <= 768 ? "deposit" : "returns");
  const [depositAmount, setDepositAmount] = useState("");
  const [depositToken, setDepositToken] = useState("BGSC");
  const [depositForOthers, setDepositForOthers] = useState(false);
  const [recipientAddress, setRecipientAddress] = useState("");
  const [instantWithdrawAmount, setInstantWithdrawAmount] = useState("");
  const [withdrawShares, setWithdrawShares] = useState("");
  const [isPrivate, setIsPrivate] = useState(false);
  const [nextRoundTime, setNextRoundTime] = useState("");
  const [isUpdatingWithdrawBalance, setIsUpdatingWithdrawBalance] = useState(false);
  const [pendingWithdrawAmount, setPendingWithdrawAmount] = useState(0n);
  
  // 다음 라운드 시간 계산
  const nextRoundInfo = useMemo(() => getNextRoundStartTime(language), [language]);
  const [depositButtonState, setDepositButtonState] = useState("deposit");
  const [selectedGasSpeed, setSelectedGasSpeed] = useState("standard");
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [modalStep, setModalStep] = useState('approval');
  
  // Track if we've auto-loaded transaction history
  const hasAutoLoadedHistory = useRef(false);
  
  // Helper function to ensure minimum TVL
  const getEffectiveTVL = () => {
    const minThreshold = BigInt('10000000000000000000000000'); // 10M BGSC (10,000,000 with 18 decimals)
    const currentTVL = safeBigInt(vaultMetrics.totalValueLocked || '0');
    
    // 실제 TVL이 10M BGSC 미만인 경우 10M 사용
    return currentTVL < minThreshold ? minThreshold.toString() : vaultMetrics.totalValueLocked;
  };

  // Dynamic text and round status
  const dynamicText = useMemo(() => getDynamicText(language), [language]);
  const roundStatus = useMemo(() => getCurrentRoundStatus(), []);
  const instantWithdrawInfo = useMemo(() => getInstantWithdrawDeadline(language), [language]);

  // BNB balance
  const { data: bnbBalance } = useBalance({
    address: address,
  });

  // scroll, responsive, mobile wallet detection
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };

    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    handleResize();
    
    // DApp 브라우저 감지
    const isDapp = MobileWalletUtils.isDappBrowser();
    setIsDappBrowser(isDapp);
    
    // 모바일 지갑 감지
    if (MobileWalletUtils.isMobile()) {
      const walletType = MobileWalletUtils.detectWalletApp();
      
      // 펜딩 트랜잭션 복구
      const pendingTxs = MobileWalletUtils.getPendingTransactions();
      if (pendingTxs.length > 0) {
        toast.loading('이전 트랜잭션을 확인하고 있습니다...', { id: 'pending-tx-recovery' });
      }
      
      // 오래된 트랜잭션 정리
      MobileWalletUtils.cleanOldTransactions();
    }
    
    window.addEventListener("scroll", handleScroll);
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  

  // Transaction recovery and round time update
  useEffect(() => {
    // 펜딩 트랜잭션 복구 (연결된 상태에서만)
    if (isConnected && address) {
      const recoverPendingTransactions = async () => {
        const pendingTxs = MobileWalletUtils.getPendingTransactions();
        
        if (pendingTxs.length > 0) {
          
          for (const tx of pendingTxs) {
            try {
              // publicClient가 있으면 트랜잭션 상태 확인
              if (tx.hash && publicClient) {
                const receipt = await publicClient.getTransactionReceipt({ hash: tx.hash });
                
                if (receipt) {
                  const status = receipt.status === 'success' ? 'success' : 'failed';
                  MobileWalletUtils.updateTransactionState(tx.hash, status);
                  
                  if (status === 'success') {
                    toast.success(
                      language === 'ko'
                        ? `${tx.action} 트랜잭션이 성공적으로 완료되었습니다.`
                        : `${tx.action} transaction completed successfully`,
                      { id: `recovered-${tx.hash}` }
                    );
                    
                    // 데이터 새로고침
                    refreshAllData();
                  } else {
                    toast.error(
                      language === 'ko'
                        ? `${tx.action} 트랜잭션이 실패했습니다`
                        : `${tx.action} transaction failed`,
                      { id: `recovered-${tx.hash}` }
                    );
                  }
                } else {
                  // 아직 펜딩 중
                  if (Date.now() - tx.timestamp > 600000) { // 10분 이상 경과
                    toast.error(
                      language === 'ko'
                        ? `${tx.action} 트랜잭션이 지연되고 있습니다. 지갑에서 확인해주세요.`
                        : `${tx.action} transaction is delayed. Please check your wallet.`,
                      { id: `delayed-${tx.hash}` }
                    );
                  }
                }
              }
            } catch (error) {
              console.error('Error recovering transaction:', error);
            }
          }
        }
      };
      
      recoverPendingTransactions();
    }
    
    // 라운드 시간 업데이트
    const updateTime = () => setNextRoundTime(getTimeUntilNextRound());
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, [isConnected, address, publicClient, language, refreshAllData]);

  // Mobile menu body scroll lock
  useEffect(() => {
    document.body.style.overflow = showMobileMenu ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [showMobileMenu]);

  // Auto-refresh transaction history when entering mypage tab
  useEffect(() => {
    if (activeTab === "mypage" && !hasAutoLoadedHistory.current && isConnected) {
      // Small delay to ensure tab transition is complete
      const timer = setTimeout(() => {
        refreshHistory();
        hasAutoLoadedHistory.current = true;
      }, 300);
      
      return () => clearTimeout(timer);
    }
  }, [activeTab, isConnected, refreshHistory]);

  // Calculated values
  const availableBalance = useMemo(() => {
    if (depositToken === "BNB" && vaultInfo.isWBNB) {
      return bnbBalance?.value?.toString() || "0";
    }
    return balances.token;
  }, [depositToken, vaultInfo.isWBNB, balances.token, bnbBalance]);

  const expectedShares = useMemo(() => {
    if (!depositAmount || !vaultMetrics.pricePerShare) {
      return 0n;
    }

    try {
      const amount = parseAmount(depositAmount, vaultInfo.decimals);
      const price = safeBigInt(vaultMetrics.pricePerShare);
      const safePrice =
        price === 0n ? BigInt(10) ** BigInt(vaultInfo.decimals) : price;

      return calculatePointsFromBGSC(amount, safePrice, vaultInfo.decimals);
    } catch (error) {
      SecurityUtils.secureLog("Expected points calculation failed:", error);
      return 0n;
    }
  }, [depositAmount, vaultMetrics.pricePerShare, vaultInfo.decimals]);

  const expectedBGSC = useMemo(() => {
    if (!withdrawShares || !vaultMetrics.pricePerShare) {
      return 0n;
    }

    try {
      const points = parseAmount(withdrawShares, vaultInfo.decimals);
      const price = safeBigInt(vaultMetrics.pricePerShare);
      const safePrice =
        price === 0n ? BigInt(10) ** BigInt(vaultInfo.decimals) : price;

      return calculateBGSCFromPoints(points, safePrice, vaultInfo.decimals);
    } catch (error) {
      SecurityUtils.secureLog("Expected BGSC calculation failed:", error);
      return 0n;
    }
  }, [withdrawShares, vaultMetrics.pricePerShare, vaultInfo.decimals]);

  // Gas fee calculation
  const estimatedGasFee = useMemo(() => {
    if (!depositAmount || isGasLoading) return null;

    const transactionType = depositToken === "BNB" ? "DEPOSIT_BNB" : "DEPOSIT";
    const hasApproval =
      !vaultInfo.isWBNB && needsApproval && needsApproval(depositAmount);

    return estimateTransactionCost(
      transactionType,
      gasPrices[selectedGasSpeed],
      hasApproval
    );
  }, [
    depositAmount,
    depositToken,
    vaultInfo.isWBNB,
    needsApproval,
    gasPrices,
    selectedGasSpeed,
    isGasLoading,
  ]);

  // Input validation - 최소 1000 BGSC
  const depositValidation = useMemo(() => {
    if (!depositAmount) return { valid: true };
    return validateAmount(
      depositAmount,
      availableBalance,
      "10000", // 최소 10000 BGSC
      vaultInfo.decimals
    );
  }, [depositAmount, availableBalance, vaultInfo.decimals]);

  const instantWithdrawValidation = useMemo(() => {
    if (!instantWithdrawAmount) return { valid: true };
    return validateAmount(
      instantWithdrawAmount,
      userBalance.pendingDepositAmount,
      "10000", // 최소 10000 BGSC
      vaultInfo.decimals
    );
  }, [
    instantWithdrawAmount,
    userBalance.pendingDepositAmount,
    vaultInfo.decimals,
  ]);

  const withdrawValidation = useMemo(() => {
    if (!withdrawShares) return { valid: true };
    // 펜딩 중인 금액을 차감한 실제 사용 가능한 포인트
    const availablePoints = safeBigInt(userBalance.walletPoints) - pendingWithdrawAmount;
    return validateAmount(
      withdrawShares,
      availablePoints.toString(),
      "0",
      vaultInfo.decimals
    );
  }, [withdrawShares, userBalance.walletPoints, vaultInfo.decimals, pendingWithdrawAmount]);

  // Handlers with debounce protection
  const [isProcessingDeposit, setIsProcessingDeposit] = useState(false);

  // Reset approval status when deposit amount changes significantly
  useEffect(() => {
    // 금액이 변경되고 idle 상태가 아닐 때만 확인
    if (approvalStatus === "approved" && depositAmount) {
      const needsNewApproval = needsApproval && needsApproval(depositAmount);
      if (needsNewApproval) {
        setApprovalStatus("idle");
      }
    }
  }, [depositAmount, needsApproval, approvalStatus, setApprovalStatus]);

  // Deposit button state update - simplified and more reliable
  useEffect(() => {
    
    if (!depositAmount || depositAmount === "0") {
      setDepositButtonState("deposit");
      return;
    }

    // If currently approving or approval is pending
    if (isApprovingFromHook || approvalStatus === "pending") {
      setDepositButtonState("approval_pending");
      return;
    }

    // BNB deposits don't need approval
    if (depositToken === "BNB" && vaultInfo.isWBNB) {
      setDepositButtonState("ready_to_deposit");
      return;
    }

    // Always check actual allowance, not just approval status
    const approvalNeeded = needsApproval && needsApproval(depositAmount);
    
    if (approvalNeeded) {
      setDepositButtonState("approval_needed");
    } else {
      setDepositButtonState("ready_to_deposit");
    }
  }, [
    depositAmount,
    depositToken,
    vaultInfo.isWBNB,
    needsApproval,
    approvalStatus,
    isApprovingFromHook,
  ]);

  
  const handleDepositSubmit = async () => {
    if (!depositAmount || !depositValidation.valid) return;
    
    // Prevent multiple clicks and add debounce protection
    if (isProcessingDeposit || isAnyLoading || depositButtonState === "approval_pending") return;
    
    // BNB deposits don't need approval
    if (depositToken === "BNB" && vaultInfo.isWBNB) {
      setIsProcessingDeposit(true);
      try {
        const result = await handleDeposit(
          depositAmount,
          true,
          depositForOthers ? recipientAddress : null
        );

        if (result === true) {
          setDepositAmount("");
          setRecipientAddress("");
          setDepositButtonState("deposit");
          
          // 입금 후 데이터 새로고침
          toast.loading(
            language === 'ko' 
              ? '잔액을 업데이트하는 중...' 
              : 'Deposit successful. Updating balance...',
            { 
              id: 'deposit-update',
              duration: 500 
            }
          );
          
          // 전체 데이터 새로고침
          setTimeout(async () => {
            await refreshAllData();
            await refreshBalances();
            toast.dismiss('deposit-update');
          }, 1500);
          
          // 추가 업데이트
          setTimeout(async () => {
            await refreshAllData();
            await refreshBalances();
          }, 3000);
        }
      } catch (error) {
        console.error("Deposit error:", error);
      } finally {
        setIsProcessingDeposit(false);
      }
      return;
    }
    
    // For BGSC tokens, show the modal for 2-step process
    if (depositButtonState === "approval_needed") {
      setModalStep('approval');
      setShowDepositModal(true);
    } else if (depositButtonState === "ready_to_deposit") {
      setModalStep('deposit');
      setShowDepositModal(true);
    }
  };

  const handleModalConfirm = async () => {
    setShowDepositModal(false);
    setIsProcessingDeposit(true);
    
    try {
      if (modalStep === 'approval') {
        // Handle approval
        const approved = await handleApproval(depositAmount);
        if (approved) {
          setDepositButtonState("approval_pending");
          
          // Show success message and guide for next step
          toast.success(
            language === 'ko' 
              ? '토큰 승인 완료! 이제 볼트가 BGSC를 사용할 수 있습니다.\n\n다시 버튼을 눌러 입금을 진행해주세요!' 
              : 'Token approval complete! The vault can now use BGSC.\n\nClick the button again to proceed with deposit!',
            { duration: 6000 }
          );
        }
      } else if (modalStep === 'deposit') {
        // Handle deposit
        const result = await handleDeposit(
          depositAmount,
          false,
          depositForOthers ? recipientAddress : null
        );

        if (result === true) {
          setDepositAmount("");
          setRecipientAddress("");
          setDepositButtonState("deposit");
          
          // 입금 후 데이터 새로고침
          toast.loading(
            language === 'ko' 
              ? '잔액을 업데이트하는 중...' 
              : 'Deposit successful. Updating balance...',
            { 
              id: 'deposit-update',
              duration: 500 
            }
          );
          
          // 전체 데이터 새로고침
          setTimeout(async () => {
            await refreshAllData();
            await refreshBalances();
            toast.dismiss('deposit-update');
          }, 1500);
          
          // 추가 업데이트
          setTimeout(async () => {
            await refreshAllData();
            await refreshBalances();
          }, 3000);
        }
      }
    } catch (error) {
      console.error("Deposit error:", error);
      // Reset button state on error to allow retry
      if (approvalStatus === "approved" && depositAmount) {
        // If approval was successful but deposit failed, stay in ready_to_deposit state
        setDepositButtonState("ready_to_deposit");
      } else if (depositButtonState === "approval_needed") {
        // Stay in approval_needed state if approval failed
        setDepositButtonState("approval_needed");
      } else {
        setDepositButtonState("deposit");
        setApprovalStatus("idle");
      }
    } finally {
      setIsProcessingDeposit(false);
    }
  };

  // Removed auto-deposit after approval to prevent duplicate transactions
  // Users should manually click deposit button after approval completes

  const handleInstantWithdrawSubmit = async () => {
    if (!instantWithdrawAmount || !instantWithdrawValidation.valid) return;

    const success = await handleInstantWithdraw(instantWithdrawAmount);
    if (success) {
      setInstantWithdrawAmount("");
      
      // 참여 취소 후 데이터 새로고침
      toast.loading(
        language === 'ko' 
          ? '잔액을 업데이트하는 중...' 
          : 'Withdrawal successful. Updating balance...',
        { 
          id: 'instant-withdraw-update',
          duration: 500 
        }
      );
      
      // 전체 데이터 새로고침
      setTimeout(async () => {
        await refreshCriticalData(); // 전체 데이터 업데이트
        await refreshBalances(); // 토큰 잔액 및 allowance 업데이트
        
        // 승인 상태 확인 및 리셋
        setApprovalStatus("idle");
        toast.dismiss('instant-withdraw-update');
      }, 1500);
      
      // 추가 업데이트
      setTimeout(async () => {
        await refreshCriticalData();
        await refreshBalances();
      }, 3000);
    }
  };

  const handleWithdrawSubmit = async () => {
    if (!withdrawShares || !withdrawValidation.valid) return;

    // 요청할 포인트 금액을 BigInt로 변환
    const withdrawAmount = parseAmount(withdrawShares, vaultInfo.decimals);
    
    const success = await handleInitiateWithdraw(withdrawShares);
    if (success) {
      setWithdrawShares("");
      setIsUpdatingWithdrawBalance(true);
      setPendingWithdrawAmount(withdrawAmount);
      
      // 포인트 변환 요청 성공 후 즉시 임시 UI 업데이트
      toast.loading(
        language === 'ko' 
          ? '잔액을 업데이트하는 중...' 
          : 'Point conversion request processed. Updating balance...',
        { 
          id: 'withdraw-balance-update',
          duration: 500 
        }
      );
      
      // 블록체인 상태 업데이트를 위한 여러 번의 새로고침
      setTimeout(() => {
        refreshUserData();
      }, 1000);
      
      setTimeout(() => {
        refreshUserData();
        toast.dismiss('withdraw-balance-update');
      }, 3000);
      
      setTimeout(() => {
        refreshUserData();
        setIsUpdatingWithdrawBalance(false);
        setPendingWithdrawAmount(0n);
      }, 5000);
    }
  };

  const handleCompleteWithdrawSubmit = async () => {
    await handleCompleteWithdraw();
  };

  const copyAddress = async () => {
    if (!address) return;

    if (!SecurityUtils.rateLimiter("copy_address", 5, 60000)) {
      toast.error(t('errors.tooManyAttempts', language));
      return;
    }

    try {
      if (!SecurityUtils.validateAddress(address)) {
        toast.error(t('errors.validation', language));
        return;
      }

      await navigator.clipboard.writeText(address);
      toast.success(t('common.addressCopied', language));
    } catch (error) {
      try {
        const textArea = document.createElement("textarea");
        textArea.value = address;
        textArea.style.position = "fixed";
        textArea.style.opacity = "0";
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
        toast.success(t('common.addressCopied', language));
      } catch (fallbackError) {
        SecurityUtils.secureLog("Copy to clipboard failed:", fallbackError);
        toast.error(t('errors.copyFailed', language));
      }
    }
  };

  const setDepositPercent = (percent) => {
    const balance = safeBigInt(availableBalance);
    const amount = (balance * BigInt(percent)) / 100n;
    
    // Convert to decimal units and round to nearest 100
    const decimalAmount = Number(formatFullAmount(amount, vaultInfo.decimals));
    const roundedAmount = Math.floor(decimalAmount / 100) * 100;
    
    setDepositAmount(roundedAmount.toString());
  };

  const setInstantWithdrawMax = () => {
    setInstantWithdrawAmount(
      formatFullAmount(userBalance.withdrawableAmount, vaultInfo.decimals)
    );
  };

  const setWithdrawMax = () => {
    setWithdrawShares(
      formatFullAmount(userBalance.walletPoints, vaultInfo.decimals)
    );
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const isAnyLoading =
    isDepositing || isWithdrawing || isRedeeming || isApprovingFromHook;

  // Input handlers
  const handleDepositAmountChange = (e) => {
    const value = e.target.value;
    const sanitized = SecurityUtils.sanitizeInput(value, 50);
    
    // BGSC 예치의 경우 숫자만 입력 가능
    if (depositToken === "BGSC") {
      const integerFiltered = sanitized.replace(/[^0-9]/g, '');
      // 앞자리 0 제거
      const finalValue = integerFiltered.replace(/^0+/, '') || '';
      setDepositAmount(finalValue);
    } else {
      const filtered = filterNumberInput(sanitized, vaultInfo.decimals);
      setDepositAmount(filtered);
    }
  };

  const handleRecipientAddressChange = (e) => {
    const value = e.target.value;
    const sanitized = SecurityUtils.sanitizeInput(value, 50);
    setRecipientAddress(sanitized);
  };

  // BGSC 예치 금액 blur 핸들러 - 100단위로 조정
  const handleDepositAmountBlur = () => {
    if (depositToken === "BGSC" && depositAmount) {
      const numValue = parseInt(depositAmount, 10);
      if (!isNaN(numValue)) {
        const roundedValue = Math.round(numValue / 100) * 100;
        setDepositAmount(roundedValue.toString());
      }
    }
  };

  const handleInstantWithdrawAmountChange = (e) => {
    const value = e.target.value;
    const sanitized = SecurityUtils.sanitizeInput(value, 50);
    
    // 숫자만 입력 가능
    const integerFiltered = sanitized.replace(/[^0-9]/g, '');
    // 앞자리 0 제거
    const finalValue = integerFiltered.replace(/^0+/, '') || '';
    setInstantWithdrawAmount(finalValue);
  };

  const handleWithdrawSharesChange = (e) => {
    const value = e.target.value;
    const sanitized = SecurityUtils.sanitizeInput(value, 50);
    const filtered = filterNumberInput(sanitized, vaultInfo.decimals);
    setWithdrawShares(filtered);
  };

  // 예치 취소 금액 blur 핸들러 - 100단위로 조정
  const handleInstantWithdrawAmountBlur = () => {
    if (instantWithdrawAmount) {
      const numValue = parseInt(instantWithdrawAmount, 10);
      if (!isNaN(numValue)) {
        const roundedValue = Math.round(numValue / 100) * 100;
        setInstantWithdrawAmount(roundedValue.toString());
      }
    }
  };

  // Deposit button configuration
  const getDepositButtonConfig = () => {
    // Check if currently processing to prevent duplicate actions
    if (isAnyLoading || isProcessingDeposit) {
      return {
        text: t('common.processing', language),
        icon: <Icons.Loader />,
        className: "action-button primary",
        disabled: true,
      };
    }

    switch (depositButtonState) {
      case "approval_needed":
        return {
          text: t('main.deposit.approveToken', language, { token: depositToken }),
          icon: <Icons.CheckCircle />,
          className: "action-button primary",
          disabled: !depositAmount || !depositValidation.valid || isProcessingDeposit,
        };
      case "approving":
        return {
          text: t('main.deposit.approvingToken', language),
          icon: <Icons.Loader />,
          className: "action-button primary",
          disabled: true,
        };
      case "approval_pending":
        return {
          text: t('main.deposit.processingApproval', language),
          icon: <Icons.Clock />,
          className: "action-button primary",
          disabled: true,
        };
      case "ready_to_deposit":
        return {
          text: t('main.deposit.depositWithToken', language, { token: depositToken }),
          icon: null,
          className: "action-button primary",
          disabled: !depositAmount || !depositValidation.valid || isProcessingDeposit,
        };
      default:
        return {
          text: t('main.deposit.joinWith', language, { token: depositToken }),
          icon: null,
          className: "action-button primary",
          disabled: !depositAmount || !depositValidation.valid || isProcessingDeposit,
        };
    }
  };

  // Secure balance render
  const renderSecureBalance = (balance, isPrivate, suffix = "") => {
    if (isPrivate) {
      return <span data-private="true">••••••</span>;
    }

    const sanitizedBalance = SecurityUtils.escapeHtml(balance.toString());
    return sanitizedBalance + suffix;
  };

  return (
    <div className="app">
      {/* CSS for mobile price box animation and scrollbar removal */}
      <style dangerouslySetInnerHTML={{ __html: `
        /* Remove scrollbars globally */
        * {
          scrollbar-width: none; /* Firefox */
          -ms-overflow-style: none; /* IE and Edge */
        }
        
        *::-webkit-scrollbar {
          display: none; /* Chrome, Safari, Opera */
        }
        
        /* Ensure no horizontal scroll */
        html, body {
          overflow-x: hidden;
          max-width: 100%;
        }
        
        .app {
          overflow-x: hidden;
        }
        
        .main-section {
          overflow: visible;
        }
        
        .balance-display {
          overflow: visible;
        }
        
        .main-content-wrapper {
          overflow: visible;
        }
        
        /* Adjust stats container margin */
        .stats-container {
          margin-bottom: 25px !important;
        }
        
        @keyframes pulseGlow {
          0% {
            box-shadow: 0 4px 12px rgba(140, 90, 255, 0.1);
          }
          50% {
            box-shadow: 0 4px 20px rgba(140, 90, 255, 0.3), 0 0 30px rgba(0, 212, 255, 0.2);
          }
          100% {
            box-shadow: 0 4px 12px rgba(140, 90, 255, 0.1);
          }
        }
        
        .mobile-price-box {
          position: relative;
          overflow: hidden;
        }
        
        .mobile-price-box::before {
          content: '';
          position: absolute;
          top: -50%;
          left: -50%;
          width: 200%;
          height: 200%;
          background: linear-gradient(
            45deg,
            transparent,
            rgba(140, 90, 255, 0.1),
            transparent
          );
          animation: shimmer 3s infinite;
        }
        
        @keyframes shimmer {
          0% {
            transform: translateX(-100%) translateY(-100%);
          }
          100% {
            transform: translateX(100%) translateY(100%);
          }
        }
      `}} />
      

      {/* Header */}
      <header className="header-wrapper">
        <div className="header-container">
          <div className="logo-section">
            <img
              onClick={scrollToTop}
              style={{ cursor: "pointer" }}
              src={`${process.env.PUBLIC_URL}/logo.png`}
              className="logo"
              alt="Logo"
            />
            <div className="logo-right">
              <img src={`${process.env.PUBLIC_URL}/logo-text.png`} className="logo-text" alt="Logo" />
              <div className="logo-info">
                <span>{t('main.stats.round', language)} {vaultInfo.currentRound}</span>
                <span>{t('main.stats.next', language)}: {nextRoundInfo.formattedDate}</span>
                <span className="live-trading-highlight">{t('main.stats.liveTrading', language)}</span>
              </div>
            </div>
          </div>

          {!isMobile && (
            <div className="wallet-section desktop-only">
              <HeaderLanguageToggle />
              <div className="event-badge">
                <div className="event-dot" />
                <span className="event-text">{livePrice} {t('main.stats.bgscPerPoint', language)} </span>
                <span
                  className={`price-change ${
                    parseFloat(priceChange) >= 0 ? "positive" : "negative"
                  }`}
                >
                  {parseFloat(priceChange) >= 0 ? "+" : ""}
                  {priceChange}%
                </span>
              </div>

              {isConnected && address ? (
                <button
                  onClick={openAccountModal}
                  className="address-display desktop-only"
                  style={{
                    background: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    padding: 0,
                    font: 'inherit',
                    color: 'inherit',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}
                >
                  {shortenAddress(address)}
                  <svg 
                    width="14" 
                    height="14" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2"
                    style={{ opacity: 0.6 }}
                  >
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                    <polyline points="16 17 21 12 16 7" />
                    <line x1="21" y1="12" x2="9" y2="12" />
                  </svg>
                </button>
              ) : (
                <ConnectButton 
                  label={language === 'ko' ? '지갑 연결' : 'Connect Wallet'}
                  accountStatus="address"
                  chainStatus="none"
                  showBalance={false}
                />
              )}
            </div>
          )}
          {isMobile && (
            <div className="mobile-header-right mobile-only">
              <HeaderLanguageToggle />
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="main-container">
        <section className="main-section">
          <div className="main-background">
            <div className="main-background-triangle" />
            <div className="main-background-up" />
          </div>
          <div className="main-content-wrapper">
            <div className="balance-display">
              {isMobile && (
                <>
                  <div className="wallet-section mobile-only">
                    <div className="event-badge mobile-price-box" style={{
                      background: 'linear-gradient(135deg, rgba(140, 90, 255, 0.15) 0%, rgba(0, 212, 255, 0.15) 100%)',
                      border: '1px solid rgba(140, 90, 255, 0.3)',
                      borderRadius: '12px',
                      padding: '10px 20px',
                      fontSize: '18px',
                      fontWeight: '600',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      marginTop: '12px',
                      marginBottom: '12px',
                      boxShadow: '0 4px 12px rgba(140, 90, 255, 0.1)',
                      animation: 'pulseGlow 3s ease-in-out infinite'
                    }}>
                      <div className="event-dot" style={{
                        width: '12px',
                        height: '12px'
                      }} />
                      <span className="event-text" style={{
                        fontSize: '18px',
                        fontWeight: '600',
                        color: '#ffffff'
                      }}>
                        {livePrice} {t('main.stats.bgscPerPoint', language)}{" "}
                      </span>
                      <span
                        className={`price-change ${
                          parseFloat(priceChange) >= 0 ? "positive" : "negative"
                        }`}
                        style={{
                          fontSize: '16px',
                          fontWeight: '600',
                          padding: '4px 8px',
                          borderRadius: '6px',
                          background: parseFloat(priceChange) >= 0 ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)'
                        }}
                      >
                        {parseFloat(priceChange) >= 0 ? "+" : ""}
                        {priceChange}%
                      </span>
                    </div>

                    {isConnected && address ? (
                      <button
                        onClick={openAccountModal}
                        className="address-display"
                        style={{
                          background: 'transparent',
                          border: 'none',
                          cursor: 'pointer',
                          padding: 0,
                          font: 'inherit',
                          color: 'inherit',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px'
                        }}
                      >
                        {shortenAddress(address)}
                        <svg 
                          width="14" 
                          height="14" 
                          viewBox="0 0 24 24" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="2"
                          style={{ opacity: 0.6 }}
                        >
                          <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                          <polyline points="16 17 21 12 16 7" />
                          <line x1="21" y1="12" x2="9" y2="12" />
                        </svg>
                      </button>
                    ) : (
                      <div style={{ marginTop: '12px' }}>
                        {isMobile && !isDappBrowser ? (
                          // 모바일 브라우저에서 커스텀 지갑 선택 UI
                          <div style={{
                            background: 'linear-gradient(135deg, rgba(140, 90, 255, 0.1) 0%, rgba(0, 212, 255, 0.1) 100%)',
                            border: '1px solid rgba(140, 90, 255, 0.3)',
                            borderRadius: '16px',
                            padding: '20px',
                            textAlign: 'center'
                          }}>
                            <h3 style={{ margin: '0 0 16px 0', fontSize: '18px', fontWeight: '600' }}>
                              {language === 'ko' ? '지갑 선택' : 'Select Wallet'}
                            </h3>
                            <div style={{
                              display: 'grid',
                              gridTemplateColumns: '1fr',
                              gap: '12px',
                              marginBottom: '16px'
                            }}>
                              <button
                                onClick={() => {
                                  const deepLink = MobileWalletUtils.generateDeepLink('metamask', window.location.href);
                                  if (deepLink) window.location.href = deepLink;
                                }}
                                style={{
                                  background: 'rgba(255, 255, 255, 0.05)',
                                  border: '1px solid rgba(255, 255, 255, 0.1)',
                                  borderRadius: '12px',
                                  padding: '16px 8px',
                                  color: '#fff',
                                  fontSize: '14px',
                                  fontWeight: '500',
                                  cursor: 'pointer',
                                  transition: 'all 0.3s ease'
                                }}
                              >
                                MetaMask
                              </button>
                              <button
                                onClick={() => {
                                  const deepLink = MobileWalletUtils.generateDeepLink('imtoken', window.location.href);
                                  if (deepLink) window.location.href = deepLink;
                                }}
                                style={{
                                  background: 'rgba(255, 255, 255, 0.05)',
                                  border: '1px solid rgba(255, 255, 255, 0.1)',
                                  borderRadius: '12px',
                                  padding: '16px 8px',
                                  color: '#fff',
                                  fontSize: '14px',
                                  fontWeight: '500',
                                  cursor: 'pointer',
                                  transition: 'all 0.3s ease'
                                }}
                              >
                                imToken
                              </button>
                              <button
                                onClick={() => {
                                  const deepLink = MobileWalletUtils.generateDeepLink('binance', window.location.href);
                                  if (deepLink) window.location.href = deepLink;
                                }}
                                style={{
                                  background: 'rgba(255, 255, 255, 0.05)',
                                  border: '1px solid rgba(255, 255, 255, 0.1)',
                                  borderRadius: '12px',
                                  padding: '16px 8px',
                                  color: '#fff',
                                  fontSize: '14px',
                                  fontWeight: '500',
                                  cursor: 'pointer',
                                  transition: 'all 0.3s ease'
                                }}
                              >
                                Binance
                              </button>
                            </div>
                            <p style={{ fontSize: '13px', opacity: 0.7, margin: 0 }}>
                              {language === 'ko' 
                                ? '지갑 앱이 설치되어 있어야 합니다' 
                                : 'Wallet app must be installed'}
                            </p>
                          </div>
                        ) : (
                          // DApp 브라우저 또는 데스크톱에서는 RainbowKit 사용
                          <ConnectButton 
                            label={language === 'ko' ? '지갑 연결' : 'Connect Wallet'}
                            accountStatus="address"
                            chainStatus="none"
                            showBalance={false}
                          />
                        )}
                      </div>
                    )}
                  </div>
                  
                </>
              )}
            </div>

            {/* Professional Hero Section - Complete Redesign */}
            <div className="hero-section-pro">
              {isMobile ? (
                /* Mobile Layout - Single Column */
                <div className="hero-mobile-layout">
                  {/* Mobile Reward Pool */}
                  <div className="hero-card-mobile reward-pool-mobile">
                    <div className="card-inner-mobile">
                      <div className="mobile-reward-header">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                          <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        <span className="mobile-label">{language === 'ko' ? '총 보상 풀' : 'Total Reward Pool'}</span>
                      </div>
                      <div className="mobile-reward-amount">
                        <span className="mobile-number">600,000,000</span>
                        <span className="mobile-unit">BGSC</span>
                      </div>
                      <div className="mobile-reward-details">
                        {language === 'ko' ? '6라운드 • 라운드당 100,000,000' : '6 Rounds • 100M per round'}
                      </div>
                    </div>
                  </div>

                  {/* Mobile Timer */}
                  <div className="hero-card-mobile timer-mobile">
                    <div className="card-inner-mobile">
                      <div className="mobile-timer-header">
                        <div className="mobile-round-info">
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
                            <path d="M12 6V12L16 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                          </svg>
                          <span>{language === 'ko' ? `${vaultInfo.currentRound || 1}라운드` : `Round ${vaultInfo.currentRound || 1}`}</span>
                        </div>
                        <span className="mobile-badge">ACTIVE</span>
                      </div>
                      <div className="mobile-timer-content">
                        <span className="mobile-timer-label">{language === 'ko' ? '종료까지' : 'Ends in'}</span>
                        <div className="mobile-timer-display">
                          {countdown.hours.toString().padStart(2, '0')}:{countdown.minutes.toString().padStart(2, '0')}:{countdown.seconds.toString().padStart(2, '0')}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Mobile TVL & APY Row */}
                  <div className="hero-mobile-row">
                    {/* Mobile TVL */}
                    <div className="hero-card-mobile tvl-mobile">
                      <div className="card-inner-mobile compact">
                        <div className="mobile-metric-header">
                          <span className="mobile-metric-label">{language === 'ko' ? '총 예치금' : 'TVL'}</span>
                          <span className="mobile-live">LIVE</span>
                        </div>
                        <div className="mobile-metric-value">
                          <span className="mobile-tvl-number">
                            {Number(formatFullAmount(vaultMetrics.totalValueLocked || '0', vaultInfo.decimals)).toLocaleString('ko-KR', { 
                              maximumFractionDigits: 0,
                              notation: Number(formatFullAmount(vaultMetrics.totalValueLocked || '0', vaultInfo.decimals)) >= 1000000 ? 'compact' : 'standard',
                              compactDisplay: 'short'
                            })}
                          </span>
                          <span className="mobile-metric-unit">BGSC</span>
                        </div>
                      </div>
                    </div>

                    {/* Mobile APY */}
                    <div className="hero-card-mobile apy-mobile">
                      <div className="card-inner-mobile compact">
                        <div className="mobile-metric-header">
                          <span className="mobile-metric-label">{language === 'ko' ? '연 수익률' : 'APY'}</span>
                        </div>
                        <div className="mobile-metric-value">
                          <span className="mobile-apy-number">
                            {(() => {
                              const totalTVL = safeBigInt(vaultMetrics.totalValueLocked || '10000000000000000000000000');
                              const totalRewardPool = safeBigInt('600000000000000000000000000');
                              const monthlyReward = totalRewardPool / 6n;
                              const monthlyReturn = totalTVL > 0n ? (monthlyReward * 10000n) / totalTVL : 0n;
                              const annualRate = (Number(monthlyReturn) / 100) * 12;
                              return annualRate.toLocaleString('ko-KR', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
                            })()}
                          </span>
                          <span className="mobile-metric-unit">%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Mobile Notice */}
                  <div className="hero-mobile-notice">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
                      <path d="M12 16H12.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                      <path d="M12 8V12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                    <span>
                      {language === 'ko' ? '라운드 전환 전 취소 가능' : 'Cancellable before round transition'}
                    </span>
                  </div>
                </div>
              ) : (
                /* Desktop Layout - 2x2 Grid */
                <>
                  <div className="hero-main-grid">
                    {/* Left Column - Reward Pool & Round Info */}
                    <div className="hero-left-column">
                      {/* Premium Reward Pool Card */}
                      <div className="hero-card reward-pool-card">
                        <div className="card-glow-effect"></div>
                        <div className="card-inner">
                          <div className="reward-icon-wrapper">
                            <svg className="reward-icon" width="32" height="32" viewBox="0 0 24 24" fill="none">
                              <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                          </div>
                          <div className="reward-content">
                            <h3 className="reward-label">{language === 'ko' ? '총 보상 풀' : 'Total Reward Pool'}</h3>
                            <div className="reward-amount">
                              <span className="amount-number">600,000,000</span>
                              <span className="amount-unit">BGSC</span>
                            </div>
                            <div className="reward-details">
                              {language === 'ko' 
                                ? '6라운드 • 라운드당 100,000,000 BGSC' 
                                : '6 Rounds • 100M BGSC per round'}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Round Timer Card */}
                      <div className="hero-card timer-card">
                        <div className="card-inner">
                          <div className="timer-header">
                            <svg className="timer-icon" width="20" height="20" viewBox="0 0 24 24" fill="none">
                              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
                              <path d="M12 6V12L16 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                            </svg>
                            <span className="round-label">
                              {language === 'ko' ? `${vaultInfo.currentRound || 1}라운드` : `Round ${vaultInfo.currentRound || 1}`}
                            </span>
                            <span className="round-badge">ACTIVE</span>
                          </div>
                          <div className="timer-countdown">
                            <div className="time-unit">
                              <div className="time-value">{countdown.hours.toString().padStart(2, '0')}</div>
                              <div className="time-label">{language === 'ko' ? '시간' : 'HRS'}</div>
                            </div>
                            <div className="time-separator">:</div>
                            <div className="time-unit">
                              <div className="time-value">{countdown.minutes.toString().padStart(2, '0')}</div>
                              <div className="time-label">{language === 'ko' ? '분' : 'MIN'}</div>
                            </div>
                            <div className="time-separator">:</div>
                            <div className="time-unit">
                              <div className="time-value">{countdown.seconds.toString().padStart(2, '0')}</div>
                              <div className="time-label">{language === 'ko' ? '초' : 'SEC'}</div>
                            </div>
                          </div>
                          <div className="timer-footer">
                            {language === 'ko' ? '라운드 종료까지' : 'Until round ends'}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Right Column - TVL & APY */}
                    <div className="hero-right-column">
                      {/* TVL Card */}
                      <div className="hero-card tvl-card">
                        <div className="card-inner">
                          <div className="tvl-header">
                            <svg className="tvl-icon" width="20" height="20" viewBox="0 0 24 24" fill="none">
                              <path d="M19 14C19 15.394 17.928 16.591 16.414 17.523C14.916 18.445 12.691 19 10.25 19C7.809 19 5.584 18.445 4.086 17.523C2.572 16.591 1.5 15.394 1.5 14V10" stroke="currentColor" strokeWidth="2"/>
                              <path d="M19 10C19 11.394 17.928 12.591 16.414 13.523C14.916 14.445 12.691 15 10.25 15C7.809 15 5.584 14.445 4.086 13.523C2.572 12.591 1.5 11.394 1.5 10" stroke="currentColor" strokeWidth="2"/>
                              <path d="M19 10C19 11.394 17.928 12.591 16.414 13.523C14.916 14.445 12.691 15 10.25 15C7.809 15 5.584 14.445 4.086 13.523C2.572 12.591 1.5 11.394 1.5 10C1.5 8.606 2.572 7.409 4.086 6.477C5.584 5.555 7.809 5 10.25 5C12.691 5 14.916 5.555 16.414 6.477C17.928 7.409 19 8.606 19 10Z" stroke="currentColor" strokeWidth="2"/>
                              <path d="M22.5 13V17" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                              <path d="M20.5 15H22.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                            </svg>
                            <span className="tvl-label">{language === 'ko' ? '총 예치 금액' : 'Total Value Locked'}</span>
                            <span className="live-indicator">
                              <span className="live-dot"></span>
                              LIVE
                            </span>
                          </div>
                          <div className="tvl-amount">
                            <span className="tvl-number">
                              {Number(formatFullAmount(vaultMetrics.totalValueLocked || '0', vaultInfo.decimals)).toLocaleString('ko-KR', { maximumFractionDigits: 0 })}
                            </span>
                            <span className="tvl-unit">BGSC</span>
                          </div>
                          <div className="tvl-progress">
                            <div className="progress-bar">
                              <div className="progress-fill" style={{
                                width: `${Math.min((Number(formatFullAmount(vaultMetrics.totalValueLocked || '0', vaultInfo.decimals)) / 100000000) * 100, 100)}%`
                              }}></div>
                            </div>
                            <div className="progress-label">
                              {language === 'ko' ? '라운드 목표 대비' : 'vs Round Target'}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* APY Card */}
                      <div className="hero-card apy-card">
                        <div className="card-glow-effect apy-glow"></div>
                        <div className="card-inner">
                          <div className="apy-header">
                            <svg className="apy-icon" width="20" height="20" viewBox="0 0 24 24" fill="none">
                              <path d="M22 12H18L15 21L9 3L6 12H2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                            <span className="apy-label">{language === 'ko' ? '예상 연 수익률' : 'Expected APY'}</span>
                          </div>
                          <div className="apy-display">
                            <span className="apy-number">
                              {(() => {
                                const totalTVL = safeBigInt(vaultMetrics.totalValueLocked || '10000000000000000000000000');
                                const totalRewardPool = safeBigInt('600000000000000000000000000');
                                const monthlyReward = totalRewardPool / 6n;
                                const monthlyReturn = totalTVL > 0n ? (monthlyReward * 10000n) / totalTVL : 0n;
                                const annualRate = (Number(monthlyReturn) / 100) * 12;
                                return annualRate.toLocaleString('ko-KR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                              })()}
                            </span>
                            <span className="apy-symbol">%</span>
                          </div>
                          <div className="apy-subtitle">
                            {language === 'ko' ? '복리 기준' : 'Compounded'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Notice Banner */}
                  <div className="hero-notice-banner">
                    <svg className="notice-icon" width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
                      <path d="M12 16H12.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                      <path d="M12 8V12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                    <span className="notice-text">
                      {language === 'ko' 
                        ? 'BGSC 예치 후 라운드 전환 전까지 자유롭게 취소 가능 (보상 미지급)' 
                        : 'BGSC deposits can be freely cancelled before round transition (no rewards)'}
                    </span>
                  </div>
                </>
              )}
            </div>
          </div>
        </section>
      </main>
      
      {/* Tabs */}
      <div className="tabs-container">
        <div className={`tabs-wrapper ${isMobile ? "two-row-tabs" : ""}`}>
          {isMobile ? (
            <>
              {/* Mobile: First Row - 2 tabs */}
              <div className="tabs-row">
                <button
                  className={`tab-button ${activeTab === "deposit" ? "active" : ""}`}
                  onClick={() => setActiveTab("deposit")}
                >
                  {t('main.tabs.deposit', language)}
                </button>
                <button
                  className={`tab-button ${activeTab === "redeem" ? "active" : ""}`}
                  onClick={() => setActiveTab("redeem")}
                >
                  {t('main.tabs.redeem', language)}
                </button>
              </div>
              {/* Mobile: Second Row - 3 tabs */}
              <div className="tabs-row">
                <button
                  className={`tab-button ${activeTab === "convert" ? "active" : ""}`}
                  onClick={() => setActiveTab("convert")}
                >
                  {t('main.tabs.convert', language)}
                </button>
                <button
                  className={`tab-button ${activeTab === "withdraw" ? "active" : ""}`}
                  onClick={() => setActiveTab("withdraw")}
                >
                  {t('main.tabs.withdraw', language)}
                </button>
                <button
                  className={`tab-button ${activeTab === "mypage" ? "active" : ""}`}
                  onClick={() => setActiveTab("mypage")}
                >
                  {t('main.tabs.mypage', language)}
                  {isLoadingHistory && (
                    <Icons.Loader
                      style={{ marginLeft: "8px", width: "16px", height: "16px" }}
                    />
                  )}
                </button>
              </div>
            </>
          ) : (
            <>
              {/* PC: All tabs in one row */}
              <button
                className={`tab-button ${activeTab === "deposit" ? "active" : ""}`}
                onClick={() => setActiveTab("deposit")}
              >
                {t('main.tabs.deposit', language)}
              </button>
              <button
                className={`tab-button ${activeTab === "redeem" ? "active" : ""}`}
                onClick={() => setActiveTab("redeem")}
              >
                {t('main.tabs.redeem', language)}
              </button>
              <button
                className={`tab-button ${activeTab === "convert" ? "active" : ""}`}
                onClick={() => setActiveTab("convert")}
              >
                {t('main.tabs.convert', language)}
              </button>
              <button
                className={`tab-button ${activeTab === "withdraw" ? "active" : ""}`}
                onClick={() => setActiveTab("withdraw")}
              >
                {t('main.tabs.withdraw', language)}
              </button>
              <button
                className={`tab-button ${activeTab === "mypage" ? "active" : ""}`}
                onClick={() => setActiveTab("mypage")}
              >
                {t('main.tabs.mypage', language)}
                {isLoadingHistory && (
                  <Icons.Loader
                    style={{ marginLeft: "8px", width: "16px", height: "16px" }}
                  />
                )}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Tab Contents */}
      <div className={`tab-content ${activeTab === "deposit" ? "active" : ""}`}>
        <div className="tab-content-wrapper">
          {!isConnected ? (
            <WalletDisconnectedAlert />
          ) : (
          <div className="main-content deposit-withdraw-container">
            <div className="form-card deposit-card">
              <div className="form-header">
                <h2 className="form-title">{t('main.deposit.formTitle', language)}</h2>
              </div>

              <div className="token-selector">
                <div
                  className={`token-option ${
                    depositToken === "BGSC" ? "active" : ""
                  }`}
                  onClick={() => setDepositToken("BGSC")}
                >
                  BGSC
                </div>
                {vaultInfo.isWBNB && (
                  <div
                    className={`token-option ${
                      depositToken === "BNB" ? "active" : ""
                    }`}
                    onClick={() => setDepositToken("BNB")}
                  >
                    BNB
                  </div>
                )}
              </div>

              {/* Two-step process explanation for BGSC deposits */}
              {depositToken === "BGSC" && (
                <div className="info-box" style={{
                  backgroundColor: 'rgba(140, 90, 255, 0.05)',
                  border: '1px solid rgba(140, 90, 255, 0.2)',
                  borderRadius: '8px',
                  padding: '12px 16px',
                  marginBottom: '20px',
                  fontSize: '14px',
                  lineHeight: '1.5'
                }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                    <Icons.Info style={{ fontSize: '16px', color: '#8C5AFF', flexShrink: 0 }} />
                    <div>
                      <strong style={{ color: '#ffffff' }}>
                        {language === 'ko' ? '1단계: 지출 한도 승인 → 2단계: 입금 실행' : 'Step 1: Approve token → Step 2: Deposit'}
                      </strong>
                    </div>
                  </div>
                </div>
              )}

              <div className="input-group">
                <div className="input-header">
                  <span className="input-label">{t('main.deposit.participationAmount', language)}</span>
                  <span className="input-info">{t('main.deposit.minimumAmount', language)}: 10,000 BGSC</span>
                </div>
                <div className="input-field">
                  <input
                    type="text"
                    className={`input-value ${
                      !depositValidation.valid ? "input-error" : ""
                    }`}
                    placeholder="0.00"
                    value={depositAmount}
                    onChange={handleDepositAmountChange}
                    onBlur={handleDepositAmountBlur}
                    maxLength={30}
                    autoComplete="off"
                  />
                  <span className="input-suffix">
                    {SecurityUtils.escapeHtml(depositToken)}
                  </span>
                </div>
                {!depositValidation.valid && (
                  <div className="error-message">
                    <Icons.AlertTriangle />
                    <span>
                      {depositValidation.params
                        ? t(depositValidation.error, language, depositValidation.params)
                        : t(depositValidation.error, language)
                      }
                    </span>
                  </div>
                )}
                {depositToken === "BGSC" && (
                  <div style={{ marginTop: '8px', fontSize: '13px', color: '#888888' }}>
                    {language === 'ko' 
                      ? '※ 100 단위 참여 가능'
                      : '※ Please enter in increments of 100'
                    }
                  </div>
                )}
              </div>

              <div className="input-group">
                <div className="input-header with-buttons">
                  <span className="input-label">
                    {t('main.deposit.availableBalance', language)}:{" "}
                    {SecurityUtils.escapeHtml(
                      formatIntegerAmount(availableBalance, vaultInfo.decimals)
                    )}{" "}
                    {SecurityUtils.escapeHtml(depositToken)}
                  </span>
                  <div className="amount-buttons">
                    <button
                      className="amount-button"
                      onClick={() => setDepositPercent(25)}
                    >
                      25%
                    </button>
                    <button
                      className="amount-button"
                      onClick={() => setDepositPercent(50)}
                    >
                      50%
                    </button>
                    <button
                      className="amount-button"
                      onClick={() => setDepositPercent(100)}
                    >
                      MAX
                    </button>
                  </div>
                </div>


                <button
                  className={getDepositButtonConfig().className}
                  onClick={handleDepositSubmit}
                  disabled={getDepositButtonConfig().disabled}
                >
                  {getDepositButtonConfig().icon}
                  {getDepositButtonConfig().text}
                </button>
              </div>
            </div>

            <div className="form-card instant-withdraw-card">
              <div className="form-header">
                <h2 className="form-title">
                  {t('main.instantWithdraw.title', language)}
                </h2>
              </div>

              <div className="input-group">
                <div className="input-header">
                  <span className="input-label">{t('main.instantWithdraw.withdrawAmountLabel', language)}</span>
                  <span className="input-info">{t('main.deposit.minimumAmount', language)}: 10,000 BGSC</span>
                </div>
                <div className="input-field">
                  <input
                    type="text"
                    className={`input-value ${
                      !instantWithdrawValidation.valid ? "input-error" : ""
                    }`}
                    placeholder="0.00"
                    value={instantWithdrawAmount}
                    onChange={handleInstantWithdrawAmountChange}
                    onBlur={handleInstantWithdrawAmountBlur}
                    maxLength={30}
                    autoComplete="off"
                  />
                  <span className="input-suffix">{t('common.bgsc', language)}</span>
                </div>
                {!instantWithdrawValidation.valid && (
                  <div className="error-message">
                    <Icons.AlertTriangle />
                    <span>
                      {instantWithdrawValidation.params
                        ? t(instantWithdrawValidation.error, language, instantWithdrawValidation.params)
                        : t(instantWithdrawValidation.error, language)
                      }
                    </span>
                  </div>
                )}
                <div style={{ marginTop: '8px', fontSize: '13px', color: '#888888' }}>
                  {language === 'ko' 
                    ? '※ 100 단위 참여 가능'
                    : '※ Please enter in increments of 100'
                  }
                </div>
              </div>

              <div className="input-group">
                <div className="input-header">
                  <span className="input-label">
                    {t('main.instantWithdraw.availableLabel', language)}:{" "}
                    {SecurityUtils.escapeHtml(
                      formatIntegerAmount(
                        userBalance.withdrawableAmount,
                        vaultInfo.decimals
                      )
                    )}{" "}
                    BGSC
                  </span>
                  <div className="amount-buttons">
                    <button
                      className="amount-button"
                      onClick={setInstantWithdrawMax}
                      disabled={
                        safeBigInt(userBalance.withdrawableAmount) === 0n
                      }
                    >
                      MAX
                    </button>
                  </div>
                </div>
                <button
                  className="action-button secondary"
                  onClick={handleInstantWithdrawSubmit}
                  disabled={
                    !instantWithdrawAmount ||
                    !instantWithdrawValidation.valid ||
                    isAnyLoading ||
                    !userBalance.canInstantWithdraw ||
                    !instantWithdrawInfo.canWithdraw
                  }
                >
                  {isAnyLoading ? (
                    <>
                      <Icons.Loader />
                      {t('common.processing', language)}
                    </>
                  ) : !instantWithdrawInfo.canWithdraw ? (
                    t('main.instantWithdraw.notAvailable', language)
                  ) : !userBalance.canInstantWithdraw ? (
                    t('main.instantWithdraw.noDepositToCancel', language)
                  ) : (
                    <span style={{ letterSpacing: "0.2em" }}>
                      {t('main.instantWithdraw.cancelAndWithdraw', language)}
                    </span>
                  )}
                </button>
              </div>
            </div>
          </div>
          )}
        </div>
      </div>

      <div
        className={`tab-content ${
          activeTab === "redeem" ? "active" : ""
        } tab-content-small`}
      >
        <div className="tab-content-wrapper">
          {!isConnected ? (
            <WalletDisconnectedAlert />
          ) : (
          <div className="main-content">
            <div className="form-card">
              <div className="form-header">
                <h2 className="form-title">{t('main.redeem.title', language)}</h2>
                <p className="form-description redeem-description">
                  {t('main.redeem.description', language)}
                </p>
                <div style={{ marginTop: '16px', fontSize: '16px', color: '#999999' }}>
                  {language === 'ko' ? '포인트수령 까지 남은시간: ' : 'Time remaining until point collection: '}
                  <span style={{ fontSize: '24px', fontWeight: '700', color: '#FFFFFF' }}>
                    {countdown.hours.toString().padStart(2, '0')}:{countdown.minutes.toString().padStart(2, '0')}:{countdown.seconds.toString().padStart(2, '0')}
                  </span>
                </div>
              </div>


              <div
                className="input-field"
                style={{
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "4px",
                }}
              >
                <span className="input-label">{t('main.redeem.unredeemedPointsLabel', language)}</span>
                <span
                  style={{
                    fontSize: "24px",
                    fontWeight: "700",
                    color: "#FFFFFF",
                  }}
                >
                  {SecurityUtils.escapeHtml(
                    formatIntegerAmount(
                      userBalance.unredeemedPoints,
                      vaultInfo.decimals
                    )
                  )}{" "}
                  {t('main.redeem.points', language)}
                </span>
              </div>

              {safeBigInt(userBalance.unredeemedPoints) === 0n && (
                <div
                  style={{
                    marginTop: "16px",
                    fontSize: "14px",
                    color: "#666666",
                    fontStyle: "italic",
                  }}
                >
                  {t('main.redeem.noPointsAvailable', language)}
                </div>
              )}
              
              {userBalance.depositRound < vaultInfo.currentRound && safeBigInt(userBalance.pendingDepositAmount) > 0n && safeBigInt(userBalance.unredeemedPoints) > 0n && (
                <div
                  style={{
                    marginTop: "16px",
                    marginBottom: "16px",
                    padding: "12px",
                    backgroundColor: "#1a2332",
                    borderRadius: "8px",
                    border: "1px solid #2a3441",
                    fontSize: "14px",
                    color: "#10b981",
                  }}
                >
                  {t('main.redeem.bgscConvertedMessage', language)}
                </div>
              )}


              <button
                className="action-button primary"
                onClick={async () => {
                  const success = await handleMaxRedeem();
                  if (success) {
                    // 상환 성공 후 추가 새로고침
                    setTimeout(() => refreshData(), 500);
                    setTimeout(() => refreshData(), 2000);
                  }
                }}
                disabled={
                  safeBigInt(userBalance.unredeemedPoints) === 0n ||
                  isAnyLoading
                }
              >
                {isAnyLoading ? (
                  <>
                    <Icons.Loader />
                    {t('common.processing', language)}
                  </>
                ) : safeBigInt(userBalance.unredeemedPoints) > 0n ? (
                  t('main.redeem.redeemAllPoints', language)
                ) : (
                  t('main.redeem.noPointsToRedeem', language)
                )}
              </button>
            </div>
          </div>
          )}
        </div>
      </div>

      {/* Convert Tab - Point Conversion (Previous STEP 1) */}
      <div
        className={`tab-content ${activeTab === "convert" ? "active" : ""}`}
      >
        <div className="tab-content-wrapper">
          {!isConnected ? (
            <WalletDisconnectedAlert />
          ) : (
          <div className="main-content">
            <div className="form-card">
              <div className="form-header">
                <h2 className="form-title">{t('main.withdraw.step1Title', language)}</h2>
                <p className="form-description withdraw-description">
                  {t('main.withdraw.step1Description', language, { duration: dynamicText.roundDuration })}
                </p>
              </div>

              <div
                className="input-field"
                style={{
                  flexDirection: "column",
                  alignItems: "flex-start",
                  gap: "8px",
                  padding: "20px",
                }}
              >
                <span className="input-label">{t('main.withdraw.yourPointsLabel', language)}</span>
                <span
                  style={{
                    fontSize: "18px",
                    fontWeight: "700",
                    color: "#FFFFFF",
                  }}
                >
                  {isUpdatingWithdrawBalance ? (
                    <>
                      <Icons.Loader style={{ width: '14px', height: '14px', marginRight: '6px' }} />
                      {language === 'ko' ? '업데이트 중' : 'Updating'}...
                    </>
                  ) : (
                    <>
                      {SecurityUtils.escapeHtml(
                        formatIntegerAmount(
                          safeBigInt(userBalance.walletPoints) - pendingWithdrawAmount,
                          vaultInfo.decimals
                        )
                      )}{" "}
                      {t('main.redeem.points', language)}
                    </>
                  )}
                </span>
                <span style={{ fontSize: "12px", color: "#999999" }}>
                  {isUpdatingWithdrawBalance 
                    ? (language === 'ko' ? '잔액 업데이트 중...' : 'Updating balance...')
                    : t('main.withdraw.currentPoints', language)}
                </span>
              </div>

              <div className="input-group" style={{ marginTop: "20px" }}>
                <div className="input-header">
                  <span className="input-label">{t('main.withdraw.participationAmount', language)}</span>
                  <span className="input-info"></span>
                </div>
                <div className="input-field">
                  <input
                    type="text"
                    className={`input-value ${
                      !withdrawValidation.valid ? "input-error" : ""
                    }`}
                    placeholder="0.00"
                    value={withdrawShares}
                    onChange={handleWithdrawSharesChange}
                    maxLength={30}
                    autoComplete="off"
                  />
                  <span className="input-suffix">Points</span>
                </div>
                {!withdrawValidation.valid && (
                  <div className="error-message">
                    <Icons.AlertTriangle />
                    <span>
                      {withdrawValidation.params
                        ? t(withdrawValidation.error, language, withdrawValidation.params)
                        : t(withdrawValidation.error, language)
                      }
                    </span>
                  </div>
                )}
              </div>

              <div className="input-group">
                <div className="input-header">
                  <span className="input-label">
                    {t('main.withdraw.availableLabel', language)}:{" "}
                    {SecurityUtils.escapeHtml(
                      formatIntegerAmount(
                        userBalance.walletPoints,
                        vaultInfo.decimals
                      )
                    )}{" "}
                    Points
                  </span>
                  <div className="amount-buttons">
                    <button className="amount-button" onClick={setWithdrawMax}>
                      MAX
                    </button>
                  </div>
                </div>

                {/* Warning if claimable BGSC exists */}
                {safeBigInt(userBalance.claimableBGSC) > 0n && (
                  <div className="alert-box warning" style={{ marginBottom: "16px" }}>
                    <Icons.AlertTriangle />
                    <div>
                      {language === 'ko' 
                        ? '새 변환 요청을 위해 4단계에서 BGSC를 출금하세요.'
                        : 'Please withdraw your BGSC in Step 4 before making a new conversion request.'}
                    </div>
                  </div>
                )}


                <button
                  className={`action-button ${withdrawShares && withdrawValidation.valid ? 'primary' : 'secondary'}`}
                  onClick={handleWithdrawSubmit}
                  disabled={
                    !withdrawShares ||
                    !withdrawValidation.valid ||
                    isAnyLoading ||
                    safeBigInt(userBalance.walletPoints) === 0n ||
                    safeBigInt(userBalance.claimableBGSC) > 0n
                  }
                >
                  {isAnyLoading ? (
                    <>
                      <Icons.Loader />
                      {t('common.processing', language)}
                    </>
                  ) : safeBigInt(userBalance.walletPoints) === 0n ? (
                    t('main.withdraw.noPointsAvailable', language)
                  ) : safeBigInt(userBalance.claimableBGSC) > 0n ? (
                    language === 'ko' ? '먼저 BGSC를 출금하세요' : 'Withdraw BGSC first'
                  ) : (
                    t('main.withdraw.requestPointConversion', language)
                  )}
                </button>
              </div>
            </div>
          </div>
          )}
        </div>
      </div>

      {/* Withdraw Tab - BGSC Withdrawal (Previous STEP 2) */}
      <div
        className={`tab-content ${activeTab === "withdraw" ? "active" : ""}`}
      >
        <div className="tab-content-wrapper">
          {!isConnected ? (
            <WalletDisconnectedAlert />
          ) : (
          <div className="main-content">
            <div className="form-card">
              <div className="form-header">
                <h2 className="form-title">{t('main.withdraw.step2Title', language)}</h2>
                {(safeBigInt(userBalance.queuedWithdrawPoints) + pendingWithdrawAmount) > 0n && 
                 safeBigInt(userBalance.claimableBGSC) === 0n && (
                  <div style={{ marginTop: '16px', fontSize: '16px', color: '#999999' }}>
                    {language === 'ko' ? 'BGSC으로 변환 대기 시간: ' : 'BGSC withdrawal available in: '}
                    <span style={{ fontSize: '24px', fontWeight: '700', color: '#FFFFFF' }}>
                      {countdown.hours.toString().padStart(2, '0')}:{countdown.minutes.toString().padStart(2, '0')}:{countdown.seconds.toString().padStart(2, '0')}
                    </span>
                  </div>
                )}
              </div>

              <div
                className="alert-box"
                style={{
                  background:
                    safeBigInt(userBalance.claimableBGSC) > 0n
                      ? "rgba(18, 185, 131, 0.1)"
                      : (safeBigInt(userBalance.queuedWithdrawPoints) + pendingWithdrawAmount) > 0n
                      ? "rgba(245, 158, 11, 0.1)"
                      : "rgba(255, 255, 255, 0.02)",
                  borderColor:
                    safeBigInt(userBalance.claimableBGSC) > 0n
                      ? "#12B983"
                      : (safeBigInt(userBalance.queuedWithdrawPoints) + pendingWithdrawAmount) > 0n
                      ? "#F59E0B"
                      : "#374151",
                }}
              >
                {safeBigInt(userBalance.claimableBGSC) > 0n ? (
                  <>
                    <Icons.CheckCircle />
                    <div>
                      <span style={{ color: "#12B983" }}>{t('main.withdraw.withdrawAvailable', language)}</span>
                      <div
                        style={{
                          marginTop: "8px",
                          fontSize: "13px",
                          color: "#12B983",
                        }}
                      >
                        {SecurityUtils.escapeHtml(
                          formatIntegerAmount(
                            userBalance.claimableBGSC,
                            vaultInfo.decimals
                          )
                        )}{" "}
                        {language === 'ko' 
                          ? 'BGSC가 즉시 출금 가능합니다.'
                          : 'BGSC available for withdrawal. You can withdraw immediately.'}
                      </div>
                    </div>
                  </>
                ) : (safeBigInt(userBalance.queuedWithdrawPoints) + pendingWithdrawAmount) > 0n ? (
                  <>
                    <Icons.Clock />
                    <div>
                      <span style={{ color: "#F59E0B" }}>{t('main.withdraw.conversionPending', language)}</span>
                      <div
                        style={{
                          marginTop: "8px",
                          fontSize: "13px",
                          color: "#F59E0B",
                        }}
                      >
                        {SecurityUtils.escapeHtml(
                          formatIntegerAmount(
                            safeBigInt(userBalance.queuedWithdrawPoints) + pendingWithdrawAmount,
                            vaultInfo.decimals
                          )
                        )}{" "}
                        {language === 'ko' 
                          ? `포인트가 Round ${userBalance.withdrawalRound}에서 BGSC로 변환 대기`
                          : `Points pending conversion to BGSC in Round ${userBalance.withdrawalRound}.`}
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <Icons.Info />
                    <div>
                      <span style={{ color: "#666666" }}>{t('main.withdraw.noConversionRequest', language)}</span>
                      <div
                        style={{
                          marginTop: "8px",
                          fontSize: "13px",
                          color: "#666666",
                        }}
                      >
                        {t('main.withdraw.noWithdrawRequest', language)}
                      </div>
                    </div>
                  </>
                )}
              </div>

              <div className="input-field" style={{ flexDirection: "column", alignItems: "center", gap: "8px", padding: "20px" }}>
                <span style={{ fontSize: "24px", fontWeight: "700", color: safeBigInt(userBalance.claimableBGSC) > 0n ? "#12B983" : "#666666" }}>
                  {SecurityUtils.escapeHtml(formatIntegerAmount(userBalance.claimableBGSC, vaultInfo.decimals))} BGSC
                </span>
              </div>

              <button
                className="action-button primary"
                onClick={handleCompleteWithdrawSubmit}
                disabled={
                  isAnyLoading || safeBigInt(userBalance.claimableBGSC) === 0n
                }
                style={{ marginTop: "24px" }}
              >
                {isAnyLoading ? (
                  <>
                    <Icons.Loader />
                    {t('main.withdraw.processingWithdraw', language)}
                  </>
                ) : safeBigInt(userBalance.claimableBGSC) === 0n ? (
                  t('main.withdraw.noBgscToWithdraw', language)
                ) : (
                  t('main.withdraw.withdrawBgscAmount', language, {
                    amount: SecurityUtils.escapeHtml(
                      formatIntegerAmount(
                        userBalance.claimableBGSC,
                        vaultInfo.decimals
                      )
                    )
                  })
                )}
              </button>
            </div>
          </div>
          )}
        </div>
      </div>

      <div
        className={`tab-content ${
          activeTab === "mypage" ? "active" : ""
        } tab-content-small`}
      >
        <div className="tab-content-wrapper">
          {!isConnected ? (
            <WalletDisconnectedAlert />
          ) : (
          <div className="main-content">
            <div className="form-card">
              <div className="form-header">
                <h2 className="form-title">{language === 'ko' ? '내 정보' : 'My Page'}</h2>
                <p className="form-description">
                  {language === 'ko' ? '내 자산 현황을 확인하세요' : 'Check your asset status'}
                </p>
              </div>

              {/* Landing Page Link Button */}
              <div style={{ marginBottom: '24px' }}>
                <button
                  className="action-button primary"
                  onClick={() => {
                    // Open landing page in new tab
                    window.open(window.location.origin + '#landing', '_blank');
                  }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '8px',
                    background: 'linear-gradient(135deg, #8C52FF 0%, #6C52FF 100%)',
                    border: 'none',
                    fontSize: '16px',
                    fontWeight: '600',
                    letterSpacing: '0.5px'
                  }}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 2L2 7L12 12L22 7L12 2Z" />
                    <path d="M2 17L12 22L22 17" />
                    <path d="M2 12L12 17L22 12" />
                  </svg>
                  {language === 'ko' ? 'BGSC 볼트 랜딩페이지' : 'BGSC Vault Information'}
                </button>
              </div>

              {/* My Asset Status Cards */}
              <div className="cards-grid" style={{ marginBottom: '40px' }}>
                {isMobile ? (
                  <>
                    <div className="info-card-wrap">
                      <div className="info-card">
                        <div className="card-value">
                          {renderSecureBalance(
                            formatIntegerAmount(
                              userBalance.walletPoints,
                              vaultInfo.decimals
                            ),
                            isPrivate
                          )}
                        </div>
                        <div className="card-title">{t('main.stats.ownedPoints', language)}</div>
                        <div className="card-subtitle">{t('main.stats.annualOperatingProfit', language)}</div>
                      </div>
                      <div className="info-card">
                        <div className="card-value">
                          {renderSecureBalance(
                            formatIntegerAmount(
                              userBalance.unredeemedPoints,
                              vaultInfo.decimals
                            ),
                            isPrivate
                          )}
                        </div>
                        <div className="card-title">{t('main.stats.unredeemed', language)}</div>
                        <div className="card-subtitle">{t('main.stats.vaultStored', language)}</div>
                      </div>
                    </div>
                    <div className="info-card-wrap">
                      <div className="info-card">
                        <div className="card-value">
                          {renderSecureBalance(
                            formatIntegerAmount(
                              userBalance.pendingDepositAmount,
                              vaultInfo.decimals
                            ),
                            isPrivate
                          )}
                        </div>
                        <div className="card-title">{t('main.stats.currentDeposit', language)}</div>
                        <div className="card-subtitle">{t('main.stats.pendingConversion', language)}</div>
                      </div>
                      <div className="info-card">
                        <div className="card-value">
                          {renderSecureBalance(
                            formatIntegerAmount(
                              userBalance.claimableBGSC,
                              vaultInfo.decimals
                            ),
                            isPrivate
                          )}
                        </div>
                        <div className="card-title">{t('main.stats.claimableBgsc', language)}</div>
                        <div className="card-subtitle">{t('main.stats.withdrawableFromVault', language)}</div>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="info-card">
                      <div className="card-value">
                        {renderSecureBalance(
                          formatIntegerAmount(
                            userBalance.walletPoints,
                            vaultInfo.decimals
                          ),
                          isPrivate
                        )}
                      </div>
                      <div className="card-title">{t('main.stats.ownedPoints', language)}</div>
                      <div className="card-subtitle">{t('main.stats.annualOperatingProfit', language)}</div>
                    </div>
                    <div className="info-card">
                      <div className="card-value">
                        {renderSecureBalance(
                          formatIntegerAmount(
                            userBalance.unredeemedPoints,
                            vaultInfo.decimals
                          ),
                          isPrivate
                        )}
                      </div>
                      <div className="card-title">{t('main.stats.unredeemed', language)}</div>
                      <div className="card-subtitle">{t('main.stats.vaultStored', language)}</div>
                    </div>
                    <div className="info-card">
                      <div className="card-value">
                        {renderSecureBalance(
                          formatIntegerAmount(
                            userBalance.pendingDepositAmount,
                            vaultInfo.decimals
                          ),
                          isPrivate
                        )}
                      </div>
                      <div className="card-title">{t('main.stats.currentDeposit', language)}</div>
                      <div className="card-subtitle">{t('main.stats.pendingConversion', language)}</div>
                    </div>
                    <div className="info-card">
                      <div className="card-value">
                        {renderSecureBalance(
                          formatIntegerAmount(
                            userBalance.claimableBGSC,
                            vaultInfo.decimals
                          ),
                          isPrivate
                        )}
                      </div>
                      <div className="card-title">{t('main.stats.claimableBgsc', language)}</div>
                      <div className="card-subtitle">{t('main.stats.withdrawableFromVault', language)}</div>
                    </div>
                  </>
                )}
              </div>

              {/* Transaction History Section */}
              <div className="form-header">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h2 className="form-title">{t('main.history.title', language)}</h2>
                  <button
                    className="icon-button"
                    onClick={refreshHistory}
                    disabled={isLoadingHistory}
                    style={{ 
                      padding: '8px',
                      borderRadius: '8px',
                      background: 'rgba(255, 255, 255, 0.05)',
                      border: '1px solid rgba(255, 255, 255, 0.1)',
                      cursor: isLoadingHistory ? 'not-allowed' : 'pointer',
                      opacity: isLoadingHistory ? 0.5 : 1
                    }}
                  >
                    <Icons.RefreshCw style={{ 
                      width: '16px', 
                      height: '16px',
                      animation: isLoadingHistory ? 'spin 1s linear infinite' : 'none'
                    }} />
                  </button>
                </div>
                <p className="form-description">
                  {t('main.history.description', language)}
                  <span style={{ 
                    display: 'block', 
                    marginTop: '4px', 
                    fontSize: '12px', 
                    color: 'rgba(255, 255, 255, 0.5)',
                    fontStyle: 'italic'
                  }}>
                    {language === 'ko' ? '* 모든 시간은 UTC 기준으로 표시됩니다' : '* All times are displayed in UTC'}
                  </span>
                </p>
              </div>

              <div className="history-list">
                {isLoadingHistory ? (
                  <div className="empty-state">
                    <Icons.Loader />
                    <p>{t('main.history.loading', language)}</p>
                  </div>
                ) : transactions.length === 0 ? (
                  <div className="empty-state">
                    <Icons.History />
                    <p>{t('main.history.empty', language)}</p>
                  </div>
                ) : (
                  transactions.map((tx) => {
                    // Determine display type and icon
                    const getTransactionDisplay = () => {
                      // 더 세분화된 이벤트 타입 처리
                      const getDetailedEventType = () => {
                        // initiate_withdraw_transfer는 사용자가 포인트를 볼트로 이체
                        if (tx.eventType === 'initiate_withdraw_transfer') {
                          return {
                            icon: <Icons.ArrowDownLeft />, 
                            label: (
                              <>
                                {language === 'ko' ? '변환 신청' : 'Exchange Request'}
                                {isMobile && <br />}
                                <span style={{ fontSize: isMobile ? '11px' : '12px', opacity: 0.8 }}>
                                  {language === 'ko' ? ' (포인트 변환 대기)' : ' (Points → Vault Transfer)'}
                                </span>
                              </>
                            ),
                            amountType: 'points'
                          };
                        }
                        
                        // redeem_transfer는 볼트에서 사용자로 포인트 이체 (실제 상환)
                        if (tx.eventType === 'redeem_transfer') {
                          return {
                            icon: <Icons.ArrowUpRight />, 
                            label: (
                              <>
                                {language === 'ko' ? '포인트 수령 완료' : 'Points Received'}
                                {isMobile && <br />}
                                <span style={{ fontSize: isMobile ? '11px' : '12px', opacity: 0.8 }}>
                                  {language === 'ko' ? ' (볼트 → 내 지갑 이체)' : ' (Vault → My Wallet)'}
                                </span>
                              </>
                            ),
                            amountType: 'points'
                          };
                        }
                        
                        // max_redeem은 전체 포인트 상환
                        if (tx.eventType === 'max_redeem' || tx.displayType === 'MaxRedeem') {
                          return {
                            icon: <Icons.ArrowUpRight />, 
                            label: (
                              <>
                                {language === 'ko' ? '포인트 수령' : 'All Points Received'}
                                {isMobile && <br />}
                                <span style={{ fontSize: isMobile ? '11px' : '12px', opacity: 0.8 }}>
                                  {language === 'ko' ? ' (개인 지갑에 수령)' : ' (All to Wallet)'}
                                </span>
                              </>
                            ),
                            amountType: 'points'
                          };
                        }
                        
                        // complete_withdraw는 BGSC 최종 출금
                        if (tx.eventType === 'complete_withdraw') {
                          const conversionInfo = tx.shares && tx.amount ? 
                            `${Number(formatFullAmount(tx.shares, 18)).toLocaleString('ko-KR', { maximumFractionDigits: 2 })} P → ${Number(formatFullAmount(tx.amount, 18)).toLocaleString('ko-KR', { maximumFractionDigits: 2 })} BGSC` : 
                            (language === 'ko' ? '변환된 BGSC 수령' : 'Converted BGSC Received');
                          return {
                            icon: <Icons.ArrowDownLeft />, 
                            label: (
                              <>
                                {language === 'ko' ? 'BGSC 출금 완료' : 'BGSC Withdrawn'}
                                {isMobile && <br />}
                                <span style={{ fontSize: isMobile ? '11px' : '12px', opacity: 0.8 }}>
                                  {` (${conversionInfo})`}
                                </span>
                              </>
                            ),
                            amountType: 'bgsc',
                            displayAmount: tx.amount  // 출금된 BGSC 수량 표시
                          };
                        }
                        
                        // instant_withdraw는 즉시 출금
                        if (tx.eventType === 'instant_withdraw') {
                          return {
                            icon: <Icons.ArrowDownLeft />, 
                            label: (
                              <>
                                {language === 'ko' ? '참여 취소' : 'Instant withdraw'}
                                {isMobile && <br />}
                                <span style={{ fontSize: isMobile ? '11px' : '12px', opacity: 0.8 }}>
                                  {language === 'ko' ? ' (현재 라운드 참여 취소)' : ' (Cancel Current Round)'}
                                </span>
                              </>
                            ),
                            amountType: 'bgsc'
                          };
                        }
                        
                        // deposit은 예치
                        if (tx.eventType === 'deposit') {
                          return {
                            icon: <Icons.Plus />, 
                            label: (
                              <>
                                {language === 'ko' ? 'BGSC 예치' : 'BGSC Deposited'}
                                {isMobile && <br />}
                                <span style={{ fontSize: isMobile ? '11px' : '12px', opacity: 0.8 }}>
                                  {language === 'ko' ? ' (라운드 참여 시작)' : ' (Round Participation)'}
                                </span>
                              </>
                            ),
                            amountType: 'bgsc'
                          };
                        }
                        
                        // 기본값
                        return { 
                          icon: <Icons.Activity />, 
                          label: tx.methodName || tx.type || tx.eventType,
                          amountType: tx.shares ? 'points' : 'bgsc'
                        };
                      };
                      
                      return getDetailedEventType();
                    };
                    
                    const display = getTransactionDisplay();
                    const displayAmount = tx.type === 'approval' ? null : (display.displayAmount || tx.shares || tx.amount || 0n);
                    
                    return (
                      <div key={tx.txHash} className="history-item">
                        <div className="history-left">
                          <div className="history-icon">
                            {display.icon}
                          </div>
                          <div className="history-info">
                            <div className="history-action">
                              {display.label}
                              {tx.displayType === 'MaxRedeem' && (
                                <span style={{ 
                                  marginLeft: '8px', 
                                  fontSize: '11px', 
                                  color: '#00d4ff',
                                  background: 'rgba(0, 212, 255, 0.1)',
                                  padding: '2px 6px',
                                  borderRadius: '4px'
                                }}>
                                  MAX
                                </span>
                              )}
                            </div>
                            <div className="history-amount">
                              {displayAmount && (
                                <>
                                  {Number(formatFullAmount(displayAmount, vaultInfo.decimals)).toLocaleString('ko-KR', { maximumFractionDigits: 2 })}
                                  {display.amountType === 'points' 
                                    ? ` ${t('main.redeem.points', language)}` 
                                    : display.amountType === 'bgsc' 
                                    ? ` ${t('common.bgsc', language)}`
                                    : ''
                                  }
                                </>
                              )}
                              {tx.round && ` • ${t('main.history.round', language)} ${tx.round}`}
                            </div>
                          </div>
                        </div>
                        <div className="history-right">
                          <div className="history-time">
                            {formatTimestamp(tx.timestamp, language)}
                          </div>
                          <div className="history-status" style={tx.eventType === 'instant_withdraw' ? { color: '#ef4444' } : {}}>
                            • {tx.eventType === 'instant_withdraw' 
                              ? (language === 'ko' ? '취소' : 'Cancelled')
                              : t('main.history.confirmed', language)}
                          </div>
                          <a
                            href={getBSCScanLink(tx.txHash)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="icon-button"
                            style={{ marginTop: "4px" }}
                          >
                            <Icons.ExternalLink />
                          </a>
                        </div>
                      </div>
                    );
                  })
                )}
                {transactions.length > 0 && (
                  <>
                    {/* Items per page selector */}
                    <div style={{ 
                      display: 'flex', 
                      flexDirection: 'row',
                      justifyContent: isMobile ? 'center' : 'space-between', 
                      alignItems: 'center', 
                      gap: isMobile ? '16px' : '0',
                      marginTop: '24px',
                      paddingTop: '24px',
                      borderTop: '1px solid rgba(255, 255, 255, 0.1)'
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: isMobile ? '8px' : '12px' }}>
                        <span style={{ fontSize: isMobile ? '13px' : '14px', color: 'rgba(255, 255, 255, 0.7)' }}>
                          {language === 'ko' ? '페이지당' : 'Items per page'}
                        </span>
                        <select
                          value={itemsPerPage}
                          onChange={(e) => changeItemsPerPage(Number(e.target.value))}
                          style={{
                            background: 'rgba(255, 255, 255, 0.05)',
                            border: '1px solid rgba(255, 255, 255, 0.1)',
                            borderRadius: '8px',
                            padding: '8px 12px',
                            color: '#fff',
                            fontSize: '14px',
                            cursor: 'pointer'
                          }}
                        >
                          {[10, 20, 30, 40, 50].map(num => (
                            <option key={num} value={num} style={{ background: '#1a1a1a' }}>
                              {num}{language === 'ko' ? '개' : ''}
                            </option>
                          ))}
                        </select>
                      </div>
                      
                      {/* Total count */}
                      <span style={{ fontSize: isMobile ? '13px' : '14px', color: 'rgba(255, 255, 255, 0.7)' }}>
                        {language === 'ko' 
                          ? `총 ${totalCount}건의 거래` 
                          : `Total ${totalCount} transactions`}
                      </span>
                    </div>
                    
                    {/* Pagination */}
                    {totalPages > 1 && (
                      <div style={{ 
                        display: 'flex', 
                        justifyContent: 'center', 
                        alignItems: 'center', 
                        gap: isMobile ? '4px' : '8px',
                        marginTop: '20px',
                        flexWrap: isMobile ? 'nowrap' : 'wrap',
                        overflowX: isMobile ? 'auto' : 'visible',
                        maxWidth: '100%'
                      }}>
                        <button
                          onClick={() => goToPage(currentPage - 1)}
                          disabled={currentPage === 1 || isLoadingHistory}
                          style={{
                            padding: isMobile ? '6px 10px' : '8px 12px',
                            background: currentPage === 1 ? 'rgba(255, 255, 255, 0.05)' : 'rgba(255, 255, 255, 0.1)',
                            border: '1px solid rgba(255, 255, 255, 0.1)',
                            borderRadius: '8px',
                            color: currentPage === 1 ? 'rgba(255, 255, 255, 0.3)' : '#fff',
                            cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
                            fontSize: isMobile ? '12px' : '14px',
                            transition: 'all 0.2s ease',
                            whiteSpace: 'nowrap'
                          }}
                        >
                          {language === 'ko' ? '이전' : 'Previous'}
                        </button>
                        
                        {/* Page numbers */}
                        <div style={{ display: 'flex', gap: isMobile ? '2px' : '4px', flexWrap: 'nowrap', justifyContent: 'center' }}>
                          {(() => {
                            const pages = [];
                            const maxVisible = isMobile ? 3 : 5;
                            let start = Math.max(1, currentPage - Math.floor(maxVisible / 2));
                            let end = Math.min(totalPages, start + maxVisible - 1);
                            
                            if (end - start < maxVisible - 1) {
                              start = Math.max(1, end - maxVisible + 1);
                            }
                            
                            if (start > 1) {
                              pages.push(
                                <button
                                  key={1}
                                  onClick={() => goToPage(1)}
                                  disabled={isLoadingHistory}
                                  style={{
                                    padding: isMobile ? '6px 10px' : '8px 12px',
                                    background: 'rgba(255, 255, 255, 0.05)',
                                    border: '1px solid rgba(255, 255, 255, 0.1)',
                                    borderRadius: '8px',
                                    color: '#fff',
                                    cursor: 'pointer',
                                    fontSize: isMobile ? '12px' : '14px',
                                    minWidth: isMobile ? '32px' : '40px'
                                  }}
                                >
                                  1
                                </button>
                              );
                              if (start > 2) {
                                pages.push(<span key="dots1" style={{ padding: '0 4px', color: 'rgba(255, 255, 255, 0.5)' }}>...</span>);
                              }
                            }
                            
                            for (let i = start; i <= end; i++) {
                              pages.push(
                                <button
                                  key={i}
                                  onClick={() => goToPage(i)}
                                  disabled={isLoadingHistory}
                                  style={{
                                    padding: isMobile ? '6px 10px' : '8px 12px',
                                    background: i === currentPage ? 'rgba(140, 90, 255, 0.2)' : 'rgba(255, 255, 255, 0.05)',
                                    border: `1px solid ${i === currentPage ? 'rgba(140, 90, 255, 0.5)' : 'rgba(255, 255, 255, 0.1)'}`,
                                    borderRadius: '8px',
                                    color: i === currentPage ? '#8C5AFF' : '#fff',
                                    cursor: 'pointer',
                                    fontSize: isMobile ? '12px' : '14px',
                                    fontWeight: i === currentPage ? '600' : '400',
                                    minWidth: isMobile ? '32px' : '40px'
                                  }}
                                >
                                  {i}
                                </button>
                              );
                            }
                            
                            if (end < totalPages) {
                              if (end < totalPages - 1) {
                                pages.push(<span key="dots2" style={{ padding: '0 4px', color: 'rgba(255, 255, 255, 0.5)' }}>...</span>);
                              }
                              pages.push(
                                <button
                                  key={totalPages}
                                  onClick={() => goToPage(totalPages)}
                                  disabled={isLoadingHistory}
                                  style={{
                                    padding: isMobile ? '6px 10px' : '8px 12px',
                                    background: 'rgba(255, 255, 255, 0.05)',
                                    border: '1px solid rgba(255, 255, 255, 0.1)',
                                    borderRadius: '8px',
                                    color: '#fff',
                                    cursor: 'pointer',
                                    fontSize: isMobile ? '12px' : '14px',
                                    minWidth: isMobile ? '32px' : '40px'
                                  }}
                                >
                                  {totalPages}
                                </button>
                              );
                            }
                            
                            return pages;
                          })()}
                        </div>
                        
                        <button
                          onClick={() => goToPage(currentPage + 1)}
                          disabled={currentPage === totalPages || isLoadingHistory}
                          style={{
                            padding: isMobile ? '6px 10px' : '8px 12px',
                            background: currentPage === totalPages ? 'rgba(255, 255, 255, 0.05)' : 'rgba(255, 255, 255, 0.1)',
                            border: '1px solid rgba(255, 255, 255, 0.1)',
                            borderRadius: '8px',
                            color: currentPage === totalPages ? 'rgba(255, 255, 255, 0.3)' : '#fff',
                            cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
                            fontSize: isMobile ? '12px' : '14px',
                            transition: 'all 0.2s ease',
                            whiteSpace: 'nowrap'
                          }}
                        >
                          {language === 'ko' ? '다음' : 'Next'}
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
          )}
        </div>
      </div>
      

      {/* Footer */}
      <footer className="landing-footer">
        <div className="landing-footer-content">
          <div className="footer-logo-container">
            <img src={textLogo} alt="Logo" />
          </div>
          <div>
            <p className="landing-footer-subtitle">
              {t('landing.footer.subtitle', language).split('\n').map((line, i) => (
                <React.Fragment key={i}>
                  {line}
                  {i === 0 && <br />}
                </React.Fragment>
              ))}
            </p>
          </div>

          <div className="landing-footer-disclaimer">
            {t(isMobile ? 'landing.footer.disclaimerMobile' : 'landing.footer.disclaimer', language)}
          </div>

          <div className="landing-footer-sns">
            <a href="https://pf.kakao.com/_jggxan" target="_blank" rel="noopener noreferrer" className="landing-footer-sns-item">
              <img src={messageIcon} alt="KakaoTalk" />
            </a>
            <a href="https://t.me/ANT_CS" target="_blank" rel="noopener noreferrer" className="landing-footer-sns-item">
              <img src={sendIcon} alt="Telegram" />
            </a>
            <a href="https://x.com/bugscoin_bgsc" target="_blank" rel="noopener noreferrer" className="landing-footer-sns-item">
              <img src={xIcon} alt="X (Twitter)" />
            </a>
          </div>
          <div className="landing-footer-copyright">
            {t('landing.footer.copyright', language).split('**').map((part, i) => 
              i === 1 ? <strong key={i}>{part}</strong> : part
            )}
          </div>
        </div>
      </footer>

      {/* Scroll to Top Button */}
      <button
        className={`scroll-top ${showScrollTop ? "visible" : ""}`}
        onClick={scrollToTop}
      >
        <img src={iconArrowRightSmall} alt="" />
      </button>

      {/* Deposit Step Modal */}
      <DepositStepModal
        isOpen={showDepositModal}
        onClose={() => setShowDepositModal(false)}
        onConfirm={handleModalConfirm}
        step={modalStep}
        language={language}
        depositAmount={depositAmount}
      />

      <style dangerouslySetInnerHTML={{ __html: getStyles() }}></style>
    </div>
  );
}
